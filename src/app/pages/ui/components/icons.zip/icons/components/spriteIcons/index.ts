export * from './spriteIcons.component';
