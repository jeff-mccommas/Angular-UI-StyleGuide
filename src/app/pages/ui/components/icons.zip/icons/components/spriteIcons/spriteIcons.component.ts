/**
 * Created by jmccommas on 9/5/16.
 */
import {Component} from '@angular/core';


@Component({
  selector: 'sprite-icons',
  template: require('./spriteIcons.html'),
  styles: [require('./spriteIcons.scss')],

})
export class SpriteIcons {

  constructor() {
  }
}
