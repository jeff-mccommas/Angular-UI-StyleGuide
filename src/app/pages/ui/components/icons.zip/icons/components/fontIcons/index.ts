export * from './fontIcons.component';
