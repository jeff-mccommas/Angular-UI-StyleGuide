import {Component} from '@angular/core';


@Component({
  selector: 'font-icons',
  template: require('./fontIcons.html'),
})
export class FontIcons {

  constructor() {
  }
}
